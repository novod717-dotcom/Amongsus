import json, sys
from PIL import Image, ImageDraw, ImageFont
src = sys.argv[1]; ttf = sys.argv[2]
d = json.load(open(src + '/Assets/Game/Maps/Definitions/astra_research_complex_map_definition.json'))
rooms = d['rooms']; ids = {r['id']: i for i, r in enumerate(rooms)}
o = ['/* gerado por tools/gen.py a partir de astra_research_complex_map_definition.json */',
     '#ifndef MAPDATA_H', '#define MAPDATA_H', 'typedef struct { const char *name; float cx, cy, w, h; int tasks; } Room;',
     'typedef struct { int npts; float w; float x[8], y[8]; } Conn;']
o.append('#define NROOMS %d' % len(rooms))
o.append('static const Room ROOMS[NROOMS] = {')
per = d['taskDistribution']['perRoom']
for r in rooms:
    o.append('  {"%s", %g, %g, %g, %g, %d},' % (r['displayName'], r['center']['x'], r['center']['y'], r['size']['width'], r['size']['height'], per.get(r['id'], 0)))
o.append('};')
cs = d['connections']; o.append('#define NCONNS %d' % len(cs)); o.append('static const Conn CONNS[NCONNS] = {')
for c in cs:
    p = c['path'][:8]
    o.append('  {%d, %g, {%s}, {%s}},' % (len(p), c['width'], ','.join('%g' % q['x'] for q in p), ','.join('%g' % q['y'] for q in p)))
o.append('};')
sp = d['spawnPoints']; o.append('#define NSPAWN %d' % len(sp)); o.append('static const float SPAWN[NSPAWN][2] = {' + ','.join('{%g,%g}' % (s['position']['x'], s['position']['y']) for s in sp) + '};')
m = d['meetingPoint']['position']; o.append('#define MEET_X %g\n#define MEET_Y %g' % (m['x'], m['y']))
o.append('#endif')
open('source/mapdata.h', 'w').write('\n'.join(o) + '\n')
# fonte 8x12, ASCII 32..126
f = ImageFont.truetype(ttf, 11)
rows = []
for ch in range(32, 127):
    im = Image.new('L', (8, 12), 0); ImageDraw.Draw(im).text((0, -1), chr(ch), fill=255, font=f)
    rows.append('  {' + ','.join('0x%02X' % sum((1 << (7 - x)) if im.getpixel((x, y)) > 110 else 0 for x in range(8)) for y in range(12)) + '}')
open('source/font.h', 'w').write('/* gerado por tools/gen.py (Liberation Sans, OFL) */\n#ifndef FONT_H\n#define FONT_H\nstatic const unsigned char FONT[95][12] = {\n' + ',\n'.join(rows) + '\n};\n#endif\n')
print(len(rooms), 'salas', len(cs), 'conexoes')
