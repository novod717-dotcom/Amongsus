/* Camada PS3 (PSL1GHT): framebuffer RSX por software + gamepad */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <unistd.h>
#include <sysutil/video.h>
#include <sysutil/sysutil.h>
#include <rsx/rsx.h>
#include <io/pad.h>
#include "game.h"

#define CB_SIZE   0x100000
#define HOST_SIZE (32*1024*1024)
static gcmContextData *ctx; static u32 W, H, curb;
static u32 *fbuf[2]; static u32 foff[2];
static int running = 1;
static u32 soft[SW*SH];

static void sys_cb(u64 st, u64 p, void *d){ (void)p; (void)d; if (st == SYSUTIL_EXIT_GAME) running = 0; }

static void video_init(void){
  void *host = memalign(1024*1024, HOST_SIZE);
  rsxInit(&ctx, CB_SIZE, HOST_SIZE, host);
  videoState vs; videoGetState(0, 0, &vs);
  videoResolution res; videoGetResolution(vs.displayMode.resolution, &res);
  W = res.width; H = res.height;
  videoConfiguration vc; memset(&vc, 0, sizeof vc);
  vc.resolution = vs.displayMode.resolution; vc.format = VIDEO_BUFFER_FORMAT_XRGB; vc.pitch = W*4;
  videoConfigure(0, &vc, NULL, 0); videoGetState(0, 0, &vs);
  gcmSetFlipMode(GCM_FLIP_VSYNC);
  for (int i = 0; i < 2; i++){
    fbuf[i] = (u32*)rsxMemalign(64, W*H*4);
    rsxAddressToOffset(fbuf[i], &foff[i]);
    gcmSetDisplayBuffer(i, foff[i], W*4, W, H);
  }
  gcmResetFlipStatus();
}
static void flip(void){
  /* escala SWxSH -> WxH (vizinho mais proximo) */
  u32 *d = fbuf[curb];
  for (u32 y = 0; y < H; y++){ u32 *s = soft + ((y*SH)/H)*SW; u32 *o = d + y*W;
    for (u32 x = 0; x < W; x++) o[x] = s[(x*SW)/W]; }
  gcmSetFlip(ctx, curb); rsxFlushBuffer(ctx); gcmSetWaitFlip(ctx);
  curb ^= 1;
}
static void wait_flip(void){ while (gcmGetFlipStatus() != 0) usleep(200); gcmResetFlipStatus(); }

int main(int argc, const char **argv){
  (void)argc; (void)argv;
  sysUtilRegisterCallback(0, sys_cb, NULL);
  video_init(); ioPadInit(7);
  game_init(0);
  Input in; memset(&in, 0, sizeof in); int prev = 0;
  curb = 0; flip(); /* primeiro flip */
  while (running){
    sysUtilCheckCallback();
    wait_flip();
    padInfo pi; ioPadGetInfo(&pi); int h = 0; in.ax = in.ay = 0;
    if (pi.status[0]){ padData pd; ioPadGetData(0, &pd);
      if (pd.len > 0){
        if (pd.BTN_CROSS) h |= B_CROSS; if (pd.BTN_CIRCLE) h |= B_CIRCLE; if (pd.BTN_SQUARE) h |= B_SQUARE; if (pd.BTN_TRIANGLE) h |= B_TRI;
        if (pd.BTN_UP) h |= B_UP; if (pd.BTN_DOWN) h |= B_DOWN; if (pd.BTN_LEFT) h |= B_LEFT; if (pd.BTN_RIGHT) h |= B_RIGHT; if (pd.BTN_START) h |= B_START;
        in.ax = ((int)pd.ANA_L_H - 128) / 128.0f; in.ay = (128 - (int)pd.ANA_L_V) / 128.0f; /* ay>0 = cima */
        in.ay = -in.ay; /* game_update usa -ay => cima positivo no mundo */
      } }
    in.pressed = h & ~prev; in.held = h; prev = h;
    game_update(&in, 1.0f/60.0f);
    game_draw(soft);
    flip();
  }
  gcmSetWaitFlip(ctx); rsxFinish(ctx, 1); ioPadEnd();
  return 0;
}
