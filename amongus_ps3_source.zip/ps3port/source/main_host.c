/* teste headless no PC: simula partidas e grava um PPM */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"
static uint32_t fb[SW*SH];
int main(void){
  game_init(12345); Input in; int wins[2] = {0,0}, ended = 0;
  for (int round = 0; round < 40; round++){
    memset(&in, 0, sizeof in); game_init(1000 + round*7);
    in.pressed = B_CROSS; game_update(&in, 1/60.0f); in.pressed = 0;
    for (int f = 0; f < 60*60*10; f++){
      in.ax = (f/120 % 2) ? 1.0f : -1.0f; in.ay = (f/200 % 2) ? 0.7f : -0.7f; in.held = B_CROSS; in.pressed = (f % 60 == 0) ? (B_CROSS|B_SQUARE|B_TRI) : 0;
      game_update(&in, 1/60.0f);
      extern int game_state_for_test(void);
      if (game_state_for_test() == 4){ ended++; break; }
    }
    if (round == 0){ game_draw(fb); FILE *o = fopen("frame.ppm","wb"); fprintf(o,"P6\n%d %d\n255\n",SW,SH);
      for (int i = 0; i < SW*SH; i++){ fputc(fb[i]>>16,o); fputc(fb[i]>>8,o); fputc(fb[i],o); } fclose(o); }
  }
  printf("rodadas terminadas: %d/40\n", ended); return 0;
}
