#ifndef GAME_H
#define GAME_H
#include <stdint.h>
#define SW 640
#define SH 360
enum { B_CROSS=1, B_CIRCLE=2, B_SQUARE=4, B_TRI=8, B_UP=16, B_DOWN=32, B_LEFT=64, B_RIGHT=128, B_START=256 };
typedef struct { int held, pressed; float ax, ay; } Input;
void game_init(uint32_t seed);
void game_update(const Input *in, float dt);
void game_draw(uint32_t *fb); /* SW x SH, 0x00RRGGBB */
#endif
