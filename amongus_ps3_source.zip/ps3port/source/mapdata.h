/* gerado por tools/gen.py a partir de astra_research_complex_map_definition.json */
#ifndef MAPDATA_H
#define MAPDATA_H
typedef struct { const char *name; float cx, cy, w, h; int tasks; } Room;
typedef struct { int npts; float w; float x[8], y[8]; } Conn;
#define NROOMS 11
static const Room ROOMS[NROOMS] = {
  {"Central Lounge", 0, 0, 32, 24, 1},
  {"Medical Lab", -48, 12, 22, 17, 2},
  {"Xenobiology Lab", -38, 37, 24, 18, 2},
  {"Observation Deck", 0, 47, 20, 14, 1},
  {"Communications", 35, 35, 18, 14, 2},
  {"Security Control", 50, 12, 18, 15, 2},
  {"Engine Maintenance", 49, -17, 26, 18, 3},
  {"Reactor Core", 37, -43, 26, 22, 2},
  {"Power Distribution", 7, -44, 18, 15, 3},
  {"Cargo Storage", -19, -29, 30, 22, 2},
  {"Life Support", -50, -18, 22, 16, 2},
};
#define NCONNS 16
static const Conn CONNS[NCONNS] = {
  {2, 5, {-46,-44}, {20,28}},
  {2, 5, {-25,-10}, {42,46}},
  {2, 5, {10,25}, {46,40}},
  {2, 5, {42,47}, {28,20}},
  {2, 5, {50,50}, {4,-8}},
  {2, 5, {46,42}, {-27,-33}},
  {2, 5, {24,16}, {-44,-44}},
  {2, 5, {-2,-7}, {-41,-37}},
  {2, 5, {-34,-39}, {-27,-23}},
  {2, 5, {-50,-49}, {-10,3}},
  {3, 5, {-16,-30,-37}, {6,9,10}},
  {3, 5, {16,31,41}, {6,9,10}},
  {2, 6, {-7,-12}, {-12,-18}},
  {3, 4, {6,7,7}, {-12,-25,-36}},
  {3, 3, {-25,0,26}, {33,31,32}},
  {3, 3, {-39,-25,-16}, {-15,-10,-6}},
};
#define NSPAWN 15
static const float SPAWN[NSPAWN][2] = {{-8,3},{-4,5},{0,6},{4,5},{8,3},{-8,-3},{-4,-5},{0,-6},{4,-5},{8,-3},{-11,0},{11,0},{-6,0},{6,0},{0,0}};
#define MEET_X 0
#define MEET_Y 0
#endif
