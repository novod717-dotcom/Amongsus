/* Port simplificado de "Among Us style" (Unity 6) para PS3 - offline, 1 humano + 5 bots */
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "game.h"
#include "mapdata.h"
#include "font.h"

#define NP 6
#define PPU 30.0f            /* pixels por unidade (camera ortografica 6 => 12 un. de altura) */
#define SPEED 6.0f
#define MAXT 24
enum { ST_TITLE, ST_PLAY, ST_MEET, ST_RESULT, ST_END };
static const uint32_t COL[NP] = {0xE03030,0x3050E0,0x30B040,0xE0E030,0xE08020,0xA040D0};
static const char *CNAME[NP] = {"Vermelho","Azul","Verde","Amarelo","Laranja","Roxo"};

typedef struct { float x, y; int alive, imp, ntask, tasks[5], done[5], target; float cd, wait, vx, vy; } P;
typedef struct { float x, y; int room, active[NP]; } Task;
static P pl[NP]; static Task tk[MAXT]; static int ntk;
static float bx[NP], by[NP]; static int body[NP];
static int state, winner, ejected, votes[NP + 1], sel, myvote, mtimer;
static float prog, hold, flash, msgt; static char msg[64], res[96];
static uint32_t rng = 1;

static uint32_t rnd(void){ rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }
static float rf(void){ return (rnd() & 0xFFFF) / 65535.0f; }
static void say(const char *s){ snprintf(msg, sizeof msg, "%s", s); msgt = 3; }

static float segd(float px, float py, float ax, float ay, float bx_, float by_){
  float dx = bx_-ax, dy = by_-ay, l = dx*dx+dy*dy, t = l > 0 ? ((px-ax)*dx+(py-ay)*dy)/l : 0;
  if (t < 0) t = 0; if (t > 1) t = 1;
  float qx = ax+t*dx-px, qy = ay+t*dy-py; return sqrtf(qx*qx+qy*qy);
}
static int walk1(float x, float y){
  for (int i = 0; i < NROOMS; i++)
    if (fabsf(x-ROOMS[i].cx) <= ROOMS[i].w/2 && fabsf(y-ROOMS[i].cy) <= ROOMS[i].h/2) return 1;
  for (int i = 0; i < NCONNS; i++)
    for (int k = 0; k + 1 < CONNS[i].npts; k++)
      if (segd(x,y,CONNS[i].x[k],CONNS[i].y[k],CONNS[i].x[k+1],CONNS[i].y[k+1]) <= CONNS[i].w/2) return 1;
  return 0;
}
static int walk(float x, float y){ const float r = 0.4f;
  return walk1(x+r,y) && walk1(x-r,y) && walk1(x,y+r) && walk1(x,y-r); }
static void move(P *p, float dx, float dy){
  if (walk(p->x+dx, p->y)) p->x += dx;
  if (walk(p->x, p->y+dy)) p->y += dy;
}
static float dist(float ax, float ay, float bx_, float by_){ return sqrtf((ax-bx_)*(ax-bx_)+(ay-by_)*(ay-by_)); }

static void start_round(void){
  ntk = 0;
  for (int r = 0; r < NROOMS; r++) for (int k = 0; k < ROOMS[r].tasks && ntk < MAXT; k++){
    Task *t = &tk[ntk++]; t->room = r; memset(t->active, 0, sizeof t->active);
    float ox = (k % 2 ? 1 : -1) * ROOMS[r].w * 0.3f, oy = (k >= 2 ? -1 : 1) * ROOMS[r].h * 0.28f;
    t->x = ROOMS[r].cx + ox; t->y = ROOMS[r].cy + oy;
    if (r == 0) { t->x = 9; t->y = 7; }
  }
  int imp = rnd() % NP;
  for (int i = 0; i < NP; i++){
    P *p = &pl[i]; memset(p, 0, sizeof *p);
    int s = (i * 2 + (rnd() % 2)) % NSPAWN; p->x = SPAWN[s][0]; p->y = SPAWN[s][1];
    p->alive = 1; p->imp = (i == imp); p->cd = 15; p->target = -1; p->wait = rf()*2;
    body[i] = 0;
    if (!p->imp){ p->ntask = 5; for (int k = 0; k < 5; k++){ int t; do { t = rnd() % ntk; } while (tk[t].active[i]); tk[t].active[i] = 1; p->tasks[k] = t; p->done[k] = 0; } }
  }
  prog = 0; hold = 0; flash = 0; state = ST_PLAY;
  say(pl[0].imp ? "VOCE E O IMPOSTOR: [] mata, /\\ reporta" : "VOCE E TRIPULANTE: faca as tarefas [X]");
}
static float progress(void){ int tot = 0, dn = 0;
  for (int i = 0; i < NP; i++) if (!pl[i].imp){ tot += 5; for (int k = 0; k < 5; k++) dn += pl[i].done[k]; }
  return tot ? (float)dn / tot : 1; }
static int count(int imp){ int n = 0; for (int i = 0; i < NP; i++) if (pl[i].alive && pl[i].imp == imp) n++; return n; }
static void check_win(void){
  if (count(1) == 0){ winner = 0; state = ST_END; }
  else if (count(1) >= count(0)){ winner = 1; state = ST_END; }
  else if (progress() >= 1){ winner = 0; state = ST_END; }
}
static void kill(int v){ pl[v].alive = 0; body[v] = 1; bx[v] = pl[v].x; by[v] = pl[v].y; }
static void begin_meeting(const char *why){
  for (int i = 0; i < NP; i++){ body[i] = 0; if (pl[i].alive){ pl[i].x = MEET_X + 4*cosf(i*1.05f); pl[i].y = MEET_Y + 4*sinf(i*1.05f); pl[i].target = -1; } }
  memset(votes, 0, sizeof votes); sel = 0; myvote = -2; mtimer = 0; state = ST_MEET; snprintf(res, sizeof res, "%s", why);
}
static void tally(void){
  int best = NP, bv = votes[NP], tie = 0;       /* indice NP = pular */
  for (int i = 0; i < NP; i++){ if (votes[i] > bv){ bv = votes[i]; best = i; tie = 0; } else if (votes[i] == bv && best != NP) tie = 1; }
  if (best == NP || tie || bv == 0){ snprintf(res, sizeof res, "Ninguem foi ejetado (empate/skip)."); }
  else { pl[best].alive = 0; snprintf(res, sizeof res, "%s foi ejetado. %s impostor.", CNAME[best], pl[best].imp ? "ERA o" : "NAO era o"); }
  state = ST_RESULT; mtimer = 0;
}

void game_init(uint32_t seed){ rng = seed ? seed : 2463534242u; state = ST_TITLE; }

static void bot_ai(int i, float dt){
  P *p = &pl[i]; if (!p->alive) return;
  p->cd -= dt; float vx = 0, vy = 0;
  if (p->wait > 0){ p->wait -= dt; return; }
  if (p->imp && p->cd <= 0){
    int v = -1; float bd = 3.0f;
    for (int j = 0; j < NP; j++) if (j != i && pl[j].alive && !pl[j].imp){ float d = dist(p->x,p->y,pl[j].x,pl[j].y); if (d < bd){ bd = d; v = j; } }
    if (v >= 0){ int wit = 0; for (int j = 0; j < NP; j++) if (j != i && j != v && pl[j].alive && dist(p->x,p->y,pl[j].x,pl[j].y) < 8) wit++;
      if (wit == 0 || rf() < 0.02f){ kill(v); p->x = bx[v]; p->y = by[v]; p->cd = 25; if (v == 0) say("Voce foi morto!"); } }
  }
  if (p->target < 0){ p->target = rnd() % ntk; }
  Task *t = &tk[p->target]; float d = dist(p->x,p->y,t->x,t->y);
  if (d < 1.2f){
    p->wait = 2 + rf()*3;
    if (!p->imp) for (int k = 0; k < p->ntask; k++) if (p->tasks[k] == p->target && !p->done[k]) p->done[k] = 1;
    p->target = -1; return;
  }
  /* segue em linha reta; se bloqueado, desvia aleatoriamente */
  vx = (t->x-p->x)/d; vy = (t->y-p->y)/d;
  float sx = p->x, sy = p->y; move(p, vx*SPEED*0.8f*dt, vy*SPEED*0.8f*dt);
  if (dist(sx,sy,p->x,p->y) < 0.2f*dt*SPEED*0.8f){ move(p, -vy*SPEED*dt, vx*SPEED*dt); if (rf() < 0.02f) p->target = rnd() % ntk; }
  /* bots tripulantes que veem corpo reportam */
  if (!p->imp) for (int j = 0; j < NP; j++) if (body[j] && dist(p->x,p->y,bx[j],by[j]) < 5 && rf() < 0.02f){ begin_meeting("Corpo reportado por um bot."); return; }
}

void game_update(const Input *in, float dt){
  if (msgt > 0) msgt -= dt; flash += dt;
  if (state == ST_TITLE){ if (in->pressed & (B_CROSS|B_START)) { rng ^= (uint32_t)(flash*100000); start_round(); } return; }
  if (state == ST_END){ if (in->pressed & (B_CROSS|B_START)) state = ST_TITLE; return; }
  if (state == ST_RESULT){ mtimer++; if (in->pressed & B_CROSS){ state = ST_PLAY; check_win(); if (state == ST_PLAY) say("De volta ao jogo."); } return; }
  if (state == ST_MEET){
    int alive[NP + 1], n = 0; for (int i = 0; i < NP; i++) if (pl[i].alive) alive[n++] = i; alive[n++] = NP;
    if (pl[0].alive){
      if (in->pressed & B_DOWN) sel = (sel + 1) % n; if (in->pressed & B_UP) sel = (sel + n - 1) % n;
      if ((in->pressed & B_CROSS) && myvote == -2) myvote = alive[sel];
    } else if (myvote == -2) myvote = NP;
    if (myvote != -2 || ++mtimer > 60*30){
      if (myvote == -2) myvote = NP;
      memset(votes, 0, sizeof votes); votes[myvote]++;
      for (int i = 1; i < NP; i++) if (pl[i].alive){
        int v = alive[rnd() % n]; if (v == i) v = NP; if (!pl[i].imp && rf() < 0.4f) v = NP; votes[v]++; }
      tally();
    }
    return;
  }
  /* ST_PLAY */
  P *me = &pl[0];
  if (me->alive){
    float ax = in->ax, ay = in->ay;
    if (in->held & B_LEFT) ax = -1; if (in->held & B_RIGHT) ax = 1; if (in->held & B_UP) ay = -1; if (in->held & B_DOWN) ay = 1;
    float m = sqrtf(ax*ax+ay*ay); if (m > 1){ ax /= m; ay /= m; } if (m < 0.2f){ ax = ay = 0; }
    move(me, ax*SPEED*dt, -ay*SPEED*dt);
    me->cd -= dt;
    /* matar */
    if (me->imp && (in->pressed & B_SQUARE) && me->cd <= 0){
      int v = -1; float bd = 3.0f;
      for (int j = 1; j < NP; j++) if (pl[j].alive && !pl[j].imp){ float d = dist(me->x,me->y,pl[j].x,pl[j].y); if (d < bd){ bd = d; v = j; } }
      if (v >= 0){ kill(v); me->x = bx[v]; me->y = by[v]; me->cd = 20; check_win(); } else say("Ninguem por perto");
    }
    /* reportar corpo */
    if (in->pressed & B_TRI) for (int j = 0; j < NP; j++) if (body[j] && dist(me->x,me->y,bx[j],by[j]) < 4){ begin_meeting("Corpo reportado por voce."); return; }
    /* botao de emergencia */
    if ((in->pressed & B_CIRCLE) && dist(me->x,me->y,MEET_X,MEET_Y) < 4){ begin_meeting("Reuniao de emergencia!"); return; }
    /* tarefas (segurar X) */
    int near = -1;
    if (!me->imp) for (int k = 0; k < 5; k++) if (!me->done[k] && dist(me->x,me->y,tk[me->tasks[k]].x,tk[me->tasks[k]].y) < 1.8f) near = k;
    if (near >= 0 && (in->held & B_CROSS)){ hold += dt; if (hold >= 2.0f){ me->done[near] = 1; hold = 0; say("Tarefa concluida!"); } } else hold = 0;
  }
  for (int i = 1; i < NP; i++) bot_ai(i, dt);
  if (state == ST_PLAY){ prog = progress(); check_win(); }
}

/* ---------------- desenho ---------------- */
static uint32_t *F;
static void px(int x, int y, uint32_t c){ if ((unsigned)x < SW && (unsigned)y < SH) F[y*SW+x] = c; }
static void rect(int x, int y, int w, int h, uint32_t c){
  for (int j = y < 0 ? 0 : y; j < y+h && j < SH; j++) for (int i = x < 0 ? 0 : x; i < x+w && i < SW; i++) F[j*SW+i] = c; }
static void text(int x, int y, const char *s, uint32_t c){
  for (; *s; s++, x += 7){ int ch = (unsigned char)*s; if (ch < 32 || ch > 126) continue;
    for (int j = 0; j < 12; j++){ unsigned char b = FONT[ch-32][j]; for (int i = 0; i < 8; i++) if (b & (0x80 >> i)) px(x+i, y+j, c); } }
}
static void disc(int cx, int cy, int r, uint32_t c){ for (int j = -r; j <= r; j++) for (int i = -r; i <= r; i++) if (i*i+j*j <= r*r) px(cx+i, cy+j, c); }
static int sxp(float x, float cx){ return SW/2 + (int)((x-cx)*PPU); }
static int syp(float y, float cy){ return SH/2 - (int)((y-cy)*PPU); }
static void crew(int sx, int sy, uint32_t c, int dead){
  if (dead){ rect(sx-8, sy+2, 16, 6, c); disc(sx, sy+2, 5, 0xFFFFFF); return; }
  rect(sx-8, sy-4, 16, 16, c); disc(sx, sy-4, 8, c); rect(sx+1, sy-8, 9, 5, 0x9FE8FF); rect(sx-12, sy, 4, 9, c);
}

void game_draw(uint32_t *fb){
  F = fb; rect(0, 0, SW, SH, 0x05080A);
  if (state == ST_TITLE){
    text(200, 110, "AMONG US STYLE - PS3 HOMEBREW", 0xFFFFFF);
    text(232, 140, "Astra Research Complex", 0x7FD0FF);
    text(250, 190, "Pressione X para iniciar", 0xFFFF80);
    text(120, 250, "Analogico/D-pad: mover   X (segurar): tarefa   []: matar (impostor)", 0xC0C0C0);
    text(120, 266, "/\\: reportar corpo   O: botao de emergencia (centro)", 0xC0C0C0);
    text(120, 300, "Port do clone Unity 6 (chocowriter, MIT) - offline com 5 bots", 0x808080);
    return;
  }
  P *me = &pl[0]; float cx = me->x, cy = me->y;
  if (state == ST_PLAY || state == ST_END){
    for (int j = 0; j < SH; j += 2) for (int i = 0; i < SW; i += 2){
      float wx = cx + (i-SW/2)/PPU, wy = cy - (j-SH/2)/PPU;
      if (walk1(wx, wy)){ uint32_t c = ((int)floorf(wx/2)+(int)floorf(wy/2)) & 1 ? 0x2A3E48 : 0x253640; F[j*SW+i]=F[j*SW+i+1]=F[(j+1)*SW+i]=F[(j+1)*SW+i+1]=c; }
    }
    for (int r = 0; r < NROOMS; r++) text(sxp(ROOMS[r].cx,cx)-(int)strlen(ROOMS[r].name)*3, syp(ROOMS[r].cy+ROOMS[r].h/2-1.5f,cy), ROOMS[r].name, 0x6FA0B8);
    disc(sxp(MEET_X,cx), syp(MEET_Y,cy), 14, 0xC03030); text(sxp(MEET_X,cx)-18, syp(MEET_Y,cy)-6, "MESA", 0xFFFFFF);
    for (int k = 0; k < 5 && !me->imp; k++) if (!me->done[k]){ Task *t = &tk[me->tasks[k]];
      rect(sxp(t->x,cx)-7, syp(t->y,cy)-7, 14, 14, ((int)(flash*3)&1) ? 0xFFE040 : 0xC09010); }
    for (int i = 0; i < NP; i++) if (body[i]) crew(sxp(bx[i],cx), syp(by[i],cy), COL[i], 1);
    for (int i = NP-1; i >= 0; i--) if (pl[i].alive) crew(sxp(pl[i].x,cx), syp(pl[i].y,cy), COL[i], 0);
    /* HUD */
    rect(10, 10, 204, 14, 0x203020); rect(12, 12, (int)(200*prog), 10, 0x40E060); text(14, 26, "Tarefas totais", 0xB0FFB0);
    if (me->imp){ char b[48]; snprintf(b, sizeof b, me->cd > 0 ? "IMPOSTOR - kill em %ds" : "IMPOSTOR - [] pronto", (int)me->cd + 1); text(10, 44, b, 0xFF6060); }
    else { int n = 0; for (int k = 0; k < 5; k++) if (!me->done[k]) n++; char b[48]; snprintf(b, sizeof b, "Suas tarefas restantes: %d", n); text(10, 44, b, 0xFFFFFF); }
    if (!me->alive) text(10, 60, "VOCE MORREU (fantasma - assista)", 0xFF8080);
    if (hold > 0) rect(SW/2-30, SH/2+24, (int)(60*hold/2), 6, 0xFFFF40);
    if (msgt > 0) text(SW/2 - (int)strlen(msg)*3, SH-30, msg, 0xFFFFFF);
  }
  if (state == ST_MEET || state == ST_RESULT){
    rect(60, 30, SW-120, SH-60, 0x101830); text(80, 40, state == ST_MEET ? "REUNIAO - quem e o impostor?" : "RESULTADO", 0xFFFFFF);
    text(80, 56, res, 0xFFE080);
    if (state == ST_MEET){
      int n = 0;
      for (int i = 0; i < NP; i++){ int a = pl[i].alive; int y = 80 + n*30; if (a || body[i] >= 0){
        if (a){ rect(80, y, SW-160, 24, n == sel ? 0x305080 : 0x182848); disc(98, y+12, 8, COL[i]);
          char b[64]; snprintf(b, sizeof b, "%s%s", CNAME[i], i == 0 ? " (voce)" : ""); text(115, y+6, b, 0xFFFFFF); n++; } } }
      int y = 80 + n*30; rect(80, y, SW-160, 24, n == sel ? 0x305080 : 0x182848); text(115, y+6, "Pular voto", 0xFFFFFF);
      text(80, SH-52, "Cima/Baixo: escolher   X: votar", 0xA0A0A0);
    } else text(80, SH-52, "Pressione X para continuar", 0xA0A0A0);
  }
  if (state == ST_END){
    rect(140, 110, 360, 120, 0x000000); rect(142, 112, 356, 116, 0x182030);
    int win = (winner == 1) == (me->imp != 0);
    text(230, 135, winner ? "IMPOSTORES VENCERAM" : "TRIPULANTES VENCERAM", winner ? 0xFF6060 : 0x60FF90);
    text(250, 160, win ? "VOCE VENCEU!" : "VOCE PERDEU", win ? 0xFFFF60 : 0xA0A0A0);
    text(215, 195, "Pressione X para voltar ao menu", 0xC0C0C0);
  }
}
int game_state_for_test(void){ return state; }
